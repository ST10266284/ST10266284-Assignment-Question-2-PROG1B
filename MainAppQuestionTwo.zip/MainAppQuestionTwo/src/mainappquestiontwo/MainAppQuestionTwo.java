/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mainappquestiontwo;

/**
 *
 * @author lab_services_student
 */
public class MainAppQuestionTwo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          PhoneStore store = new PhoneStore(5); // Create a store with a capacity of 5 phones

        // Add phones to the store
        store.addPhone(new Phone("Samsung", "Galaxy S21", 799.99));
        store.addPhone(new Phone("Apple", "iPhone 13", 899.99));
        store.addPhone(new Phone("Google", "Pixel 6", 699.99));

        // Display the phone inventory
        store.displayInventory();
    }
}
    
    

