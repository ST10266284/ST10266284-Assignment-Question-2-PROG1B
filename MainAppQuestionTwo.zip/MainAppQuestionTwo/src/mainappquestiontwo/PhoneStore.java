/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainappquestiontwo;

/**
 *
 * @author lab_services_student
 */
public class PhoneStore {
  private Phone[] phones;
    private int numOfPhones;

    public PhoneStore(int capacity) {
        phones = new Phone[capacity];
        numOfPhones = 0;
    }

    public void addPhone(Phone phone) {
        if (numOfPhones < phones.length) {
            phones[numOfPhones] = phone;
            numOfPhones++;
        } else {
            System.out.println("Store is full. Cannot add more phones.");
        }
    }

    public void displayInventory() {
        System.out.println("Phone Inventory:");
        for (int i = 0; i < numOfPhones; i++) {
            Phone phone = phones[i];
            System.out.println("Brand: " + phone.getBrand() +
                               ", Model: " + phone.getModel() +
                               ", Price: $" + phone.getPrice());
        }
    }
     public int getNumOfPhones() {
        return numOfPhones;
    }
}


    

