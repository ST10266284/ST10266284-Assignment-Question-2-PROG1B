/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mainappquestiontwo;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author lab_services_student
 */
public class PhoneStoreTest {
    @Test
    public void testAddPhone() {
        PhoneStore store = new PhoneStore(2);

        store.addPhone(new Phone("Samsung", "Galaxy S21", 799.99));
        store.addPhone(new Phone("Apple", "iPhone 13", 899.99));

        assertEquals(2, store.getNumOfPhones());
    }

    @Test
    public void testAddPhoneToFullStore() {
        PhoneStore store = new PhoneStore(1);

        store.addPhone(new Phone("Samsung", "Galaxy S21", 799.99));
        store.addPhone(new Phone("Apple", "iPhone 13", 899.99));

        assertEquals(1, store.getNumOfPhones());
    }

    @Test
    public void testDisplayInventory() {
        PhoneStore store = new PhoneStore(3);

        store.addPhone(new Phone("Samsung", "Galaxy S21", 799.99));
        store.addPhone(new Phone("Apple", "iPhone 13", 899.99));
        store.addPhone(new Phone("Google", "Pixel 6", 699.99));

        // Redirect console output for testing
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        store.displayInventory();

        String expectedOutput = "Phone Inventory:\n" +
                                "Brand: Samsung, Model: Galaxy S21, Price: $799.99\n" +
                                "Brand: Apple, Model: iPhone 13, Price: $899.99\n" +
                                "Brand: Google, Model: Pixel 6, Price: $699.99\n";

        assertEquals(expectedOutput, outputStream.toString());
    }
}

    

